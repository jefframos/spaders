/*
  import all the plugins to extend pixi here.
*/
import * as PIXI from 'pixi.js';
import * as FILTERS from 'pixi-filters';

export default {};
